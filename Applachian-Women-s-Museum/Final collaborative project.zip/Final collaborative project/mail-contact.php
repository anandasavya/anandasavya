<?php
// Contact subject
$subject ="Contact Recieved"; 
// Details
$message .= "First Name: ".$_POST['firstname']."\n";
$message .= "Last Name: ".$_POST['lastname']."\n";
$message .= "Email: ".$_POST['email']."\n";
$message .= "Phone: ".$_POST['phone']."\n";
$message .= "Address: ".$_POST['address']."\n";
$message .= "Country: ".$_POST['country']."\n";
$message .= "Post code: ".$_POST['postcode']."\n";
$message .= "State: ".$_POST['state']."\n";
$message .= "Event: ".$_POST['event']."\n";

// Mail of sender
$mail_from=$_POST['Email']; 
// From 
$header="from: $name <$mail_from>";

// Enter your email address
$to ='sajjadsaleem.com@gmail.com';

$send_contact=mail($to,$subject,$message,$header);

// Check, if message sent to your email 
//display message "We've recived your information"
if($send_contact){
 header( 'Location: success.html') ;
}
else {
echo "ERROR";
}
?>